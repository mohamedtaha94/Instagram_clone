import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:hii/model/storymodel.dart';
import 'package:hii/views/story_viewer_screen.dart';

Widget buildStories() {
  return StreamBuilder<QuerySnapshot>(
    stream: FirebaseFirestore.instance
        .collection('stories')
        .orderBy('timestamp', descending: true)
        .snapshots(),
    builder: (context, snapshot) {
      if (!snapshot.hasData) {
        return const CircularProgressIndicator();
      }

      final stories = snapshot.data!.docs.map((doc) {
        return StoryModel.fromDocument(doc);
      }).toList();

      return SizedBox(
        height: 100,
        child: ListView.builder(
          scrollDirection: Axis.horizontal,
          itemCount: stories.length,
          itemBuilder: (context, index) {
            final story = stories[index];
            return GestureDetector(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => StoryViewerScreen(story: story),
                  ),
                );
              },
              child: CircleAvatar(
                backgroundImage: NetworkImage(story.imageUrl),
                radius: 35,
              ),
            );
          },
        ),
      );
    },
  );
}
