// ignore_for_file: camel_case_types

class exceptions {
  String message;
  exceptions(this.message);
}
