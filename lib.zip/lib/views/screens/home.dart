// ignore_for_file: unused_field, prefer_final_fields, avoid_print, prefer_const_constructors, duplicate_ignore

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hii/control/widgets/post_widget.dart';




/*class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  FirebaseAuth _auth = FirebaseAuth.instance;
  FirebaseFirestore _firebaseFirestore = FirebaseFirestore.instance;

  // Pick image from gallery or camera
  Future<String?> pickImage() async {
    final ImagePicker picker = ImagePicker();
    final XFile? pickedFile = await picker.pickImage(source: ImageSource.gallery);
    return pickedFile?.path;
  }

  // Upload image to Firebase Storage
  Future<String> uploadImage(File imageFile) async {
    try {
      final storageRef = FirebaseStorage.instance.ref();
      String fileName = 'story_${DateTime.now().millisecondsSinceEpoch}.jpg';
      final uploadTask = storageRef.child('stories/$fileName').putFile(imageFile);

      TaskSnapshot snapshot = await uploadTask;
      String downloadUrl = await snapshot.ref.getDownloadURL();
      return downloadUrl;
    } catch (e) {
      print("Error uploading image: $e");
      return '';
    }
  }

  // Create story and save to Firestore
  Future<void> createStory() async {
    String? imagePath = await pickImage();

    if (imagePath != null) {
      File imageFile = File(imagePath);
      String imageUrl = await uploadImage(imageFile);

      if (imageUrl.isNotEmpty) {
        String username = 'user123'; // Replace with actual logic to get username

        bool success = await Firebase_Firestor().createStory(imageUrl: imageUrl, username: username);

        if (success) {
          print("Story uploaded successfully!");
        } else {
          print("Failed to upload story");
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        title: SizedBox(
          width: 105.w,
          height: 28.h,
          child: Image.asset('images/instagram.jpg'),
        ),
        leading: Image.asset('images/camera.jpg'),
        actions: [
          const Icon(
            Icons.favorite_border_outlined,
            color: Colors.black,
            size: 25,
          ),
          SizedBox(width: 20.w),
          Padding(
            padding: EdgeInsets.only(right: 19.r),
            child: Image.asset('images/send.jpg'),
          ),
        ],
        backgroundColor: const Color(0xffFAFAFA),
      ),
      body: Column(
        children: [
          buildStories(),
          Expanded(
            child: CustomScrollView(
              slivers: [
                StreamBuilder(
                  stream: _firebaseFirestore
                      .collection('posts')
                      .orderBy('time', descending: true)
                      .snapshots(),
                  builder: (context, snapshot) {
                    return SliverList(
                      delegate: SliverChildBuilderDelegate(
                        (context, index) {
                          if (!snapshot.hasData) {
                            return const Center(
                              child: CircularProgressIndicator(),
                            );
                          }
                          return PostWidget(snapshot.data!.docs[index].data());
                        },
                        childCount: snapshot.data == null ? 0 : snapshot.data!.docs.length,
                      ),
                    );
                  },
                )
              ],
            ),
          ),
          // Story Upload Button
          Padding(
            padding: EdgeInsets.all(16.r),
            child: ElevatedButton(
              onPressed: () {
                createStory(); // Trigger story creation
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue,
                minimumSize: Size(100.w, 50.h),
              ),
              child: Text('Upload Story'),
            ),
          ),
        ],
      ),
    );
  }
}*/


class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  // ignore: unused_field, prefer_final_fields
  FirebaseAuth _auth = FirebaseAuth.instance;
  // ignore: prefer_final_fields
  FirebaseFirestore _firebaseFirestore = FirebaseFirestore.instance;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
    backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      appBar: AppBar(
        centerTitle: true,
        elevation: 0,
        title: SizedBox(
          width: 105.w,
          height: 28.h,
          child: Image.asset('images/instagram.jpg'),
        ),
        leading: Image.asset('images/camera.jpg'),
        actions: [
          const Icon(
            Icons.favorite_border_outlined,
            color: Colors.black,
            size: 25,
          ),SizedBox(width: 20.w,),
          Padding(
            padding:  EdgeInsets.only(right: 19.r),
            child: Image.asset('images/send.jpg'),
          ),
        ],
        backgroundColor: Theme.of(context).scaffoldBackgroundColor,
      ),
      body: CustomScrollView(
        slivers: [
          StreamBuilder(
            stream: _firebaseFirestore
                .collection('posts')
                .orderBy('time', descending: true)
                .snapshots(),
            builder: (context, snapshot) {
              return SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    if (!snapshot.hasData) {
                      return const Center(
                        child: CircularProgressIndicator(),
                      );
                    }
                    return PostWidget(snapshot.data!.docs[index].data());
                  },
                  childCount:
                      snapshot.data == null ? 0 : snapshot.data!.docs.length,
                ),
              );
            },
          )
        ],
      ),
    );
  }
}