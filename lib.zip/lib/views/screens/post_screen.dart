import 'package:flutter/material.dart';
import 'package:hii/control/widgets/post_widget.dart';

class PostScreen extends StatelessWidget {
  final snapshot;
  // ignore: prefer_const_constructors_in_immutables
  PostScreen(this.snapshot, {super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(child: PostWidget(snapshot)),
    );
  }
}
