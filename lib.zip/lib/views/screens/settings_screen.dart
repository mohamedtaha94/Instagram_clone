import 'package:flutter/material.dart';
import 'package:hii/main.dart';

class SettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Settings'),
      ),
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Toggle Theme',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 10),
            Switch(
              value: MyApp.themeNotifier.value == ThemeMode.dark,
              onChanged: (isDarkMode) {
                MyApp.themeNotifier.value =
                    isDarkMode ? ThemeMode.dark : ThemeMode.light;
              },
            ),
          ],
        ),
     ),
);
}
}