import 'package:easy_localization/easy_localization.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:hii/control/auth/mainpage.dart';
import 'package:hii/control/firebase_Services/firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  await EasyLocalization.ensureInitialized();
  runApp(
    EasyLocalization(
      supportedLocales:const [Locale('en', 'US'), Locale('ar', 'DZ')],
      path: 'assets/translations', // <-- change the path of the translation files 
      fallbackLocale:const Locale('en', 'US'),
      child:const MyApp()
    ),
  );
}

class MyApp extends StatelessWidget {
  static final ValueNotifier<ThemeMode> themeNotifier =
      ValueNotifier(ThemeMode.light);

  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ThemeMode>(
        valueListenable: themeNotifier,
        builder: (context, currentTheme, child) {
          return MaterialApp(
            localizationsDelegates: context.localizationDelegates,
            supportedLocales: context.supportedLocales,
            locale: context.locale,
            title: 'Light and Dark Mode',
            theme: ThemeData.light(),
            darkTheme: ThemeData.dark(),
            themeMode: currentTheme,
            debugShowCheckedModeBanner: false,
            home: const ScreenUtilInit(
              designSize: Size(360, 740),
              child: MainPage(),
            ),
          );
        });
  }
}
