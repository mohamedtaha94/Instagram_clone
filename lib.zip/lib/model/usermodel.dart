class Usermodel {
  String email;
  String username;
  String bio;
  String profile;
  List following;
  List followers;
  Usermodel(this.bio, this.email, this.followers, this.following, this.profile,
      this.username);
}
