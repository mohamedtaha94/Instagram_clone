import 'package:cloud_firestore/cloud_firestore.dart';

class StoryModel {
  final String storyId;
  final String userId;
  final String imageUrl;
  final Timestamp timestamp;

  StoryModel({
    required this.storyId,
    required this.userId,
    required this.imageUrl,
    required this.timestamp,
  });

  factory StoryModel.fromDocument(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return StoryModel(
      storyId: doc.id,
      userId: data['userId'],
      imageUrl: data['imageUrl'],
      timestamp: data['timestamp'],
    );
  }
}
